# StatCompiler Export: What to Send DET

Please send us your country's DHS StatCompiler export **exactly as downloaded**. DET reads
the file and displays it the same way for every country, so you do not type, copy or
reformat any DHS numbers.

## Steps

1. Go to https://www.statcompiler.com
2. Select your country and **all available surveys** (DHS, MIS, AIS).
3. Select the 18 indicators in the checklist below.
4. Keep the figures as national totals. The exported file must show the word **Total**
   above every indicator column, not Urban, Rural or another breakdown.
5. Export as Excel (`.xlsx`).
6. Put the file in your country folder with its original name (it starts with
   `STATcompilerExport`).

## Please do not

- rename the file, delete columns, or sort or edit anything inside it
- open it and save it again (if you open it to look, close it without saving)
- copy its numbers into another file or into your profile

The last line of the file holds the official citation and the date you downloaded it.
DET uses that line as the source under the table, so it must stay in the file.

## Indicator checklist (18)

Use the names exactly as they appear in StatCompiler.

**Malaria prevalence (children 6-59 months)**
1. Malaria prevalence according to RDT
2. Malaria prevalence according to microscopy

**Mortality**
3. Under-five mortality rate
4. Pregnancy-related mortality ratio

**Nets: ownership**
5. Households with at least one insecticide-treated mosquito net (ITN)
6. Households with at least one insecticide-treated mosquito net (ITN) for every two persons who stayed in the household the previous night

**Nets: access and use**
7. Persons with access to an insecticide-treated mosquito net (ITN)
8. Population who slept under an insecticide-treated mosquito net (ITN) last night
9. Children under 5 who slept under an insecticide-treated net (ITN)
10. Pregnant women who slept under an insecticide-treated net (ITN)
11. Existing insecticide-treated mosquito nets (ITNs) used last night

**Vector control coverage**
12. Households with at least one insecticide-treated mosquito net (ITN) and/or indoor residual spraying (IRS) in the past 12 months
13. Households with at least one insecticide-treated mosquito net (ITN) for every two persons and/or indoor residual spraying (IRS) in the past 12 months

**Malaria in pregnancy**
14. SP/Fansidar 3+ doses during pregnancy

**Care seeking and treatment (children with fever)**
15. Children with fever for whom advice or treatment was sought
16. Children with fever who had blood taken from a finger or heel for testing
17. Children with fever who took a combination with artemisinin

**Anaemia**
18. Children with hemoglobin lower than 8.0 g/dl

If a survey did not measure an indicator, StatCompiler leaves the cell blank. That is normal.
