# Country profile pack: read this first

You write the story. DET draws the figures and builds the tables from your data, so every
country looks the same.

## What you send back (four things)

Put them in one folder named after your country, for example `mozambique/`:

| File | What it is |
|---|---|
| `profile_<country>.md` | Your text. Start from `profile_TEMPLATE.md` and follow the comments in it. |
| `epi_table_<country>.xlsx` | Your data. Start from `epi_table_TEMPLATE.xlsx`. |
| `STATcompilerExport....xlsx` | The DHS export, exactly as downloaded. See `STATCOMPILER_EXPORT_README.md`. |
| `Images/` | Only the images for Sections 8 and 9. |

## The workbook has these tabs (fill each one)

| Tab | What goes in it | Used for |
|---|---|---|
| Data | One row per number per year, with its source | Section 2 and Section 6a tables |
| Timeline | One row per event, with source and link | Section 5 timeline |
| Abbreviations | Every abbreviation used in your text, tables and sources, with its meaning | Abbreviations list at the end of the page |
| Health_system | One row per level of the health system | Section 7 pyramid |
| Facilities | One row per health facility, with coordinates | Section 7 facility chart and map |
| Examples, DHIS2 names | Guides. Do not fill. | |

## Seven rules

1. A number in your text must also be in the workbook, with a source. No source, no number.
2. Cite as (Author, Year) and put every citation in the references table in Section 11.
3. Do not type facility counts or shares. DET writes them from your Facilities tab.
4. Do not number figures or tables. Do not send images of anything DET draws.
5. Do not rename tabs, column headers, section headings or the `<!-- DET-FIGURE ... -->` lines.
6. Use public links only (not private Google Drive links).
7. Save the .md file as UTF-8 and check accents (Zambezia, not ZambÃ©zia).

## Before you send, check

- [ ] Every tab is filled, or you have written under "Anything else DET should know" why not.
- [ ] Every Timeline row has a Source and Link.
- [ ] Every Facilities row has a Tier (the three words only) and coordinates.
- [ ] Section 10 tables have a Source and a link or DOI on every row.
- [ ] Every (Author, Year) in the text is in the references table.
- [ ] The workbook is saved and closed.

Questions: the Data Engineering Team, MAP Dar Node.

## Writing sources and terms (please follow, reviewers check these)

- **Sources in plain words.** Write "World Bank, World Development Indicators: urban population, % of total" and not a code such as "SP.URB.TOTL.IN.ZS". Write "WHO World Malaria Report 2025, Annex 4H" and say in Notes if a number was calculated and how.
- **One source per number.** If the same measure (for example incidence or rainfall) comes from two sources, say which is which in the text, for example "reported by the national programme (DHIS2, 2022)" versus "modelled by WHO (2024)". Do not put them side by side without saying why they differ.
- **Always give the year** of every number and every figure.
- **Define abbreviations** the first time you use them, for example "National Malaria Control Programme (NMCP)", and list EVERY abbreviation you use in the `Abbreviations` tab (including common ones such as WHO, ITN and RDT).
- **Italics** for species and parasite names: *Anopheles funestus*, *An. arabiensis*, *Plasmodium falciparum*.
- Do not add a "Ref" column or table numbers of your own. DET numbers tables and figures.
