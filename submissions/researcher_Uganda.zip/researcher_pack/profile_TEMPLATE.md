<!--
==========================================================================
 COUNTRY PROFILE: CONTENT FILE (version 3)
==========================================================================
 Rename this file to profile_<country>.md (for example profile_mozambique.md).
 Keep the section headings and the lines that start with
 "<!-- DET-FIGURE" exactly as they are. DET maps each heading to a fixed
 place on the page and fills the figure lines by script.

 WHAT YOU DO, AND WHAT DET DOES
   You write:  short narrative text for each section, and the references table.
   You send:   the data workbook (epi_table_<country>.xlsx), the raw DHS
               StatCompiler export, and images only where a section says so.
   DET builds: the summary tables, the administrative map, the timeline, the
               health system diagram, the facility charts and map, and the
               vector distribution map. Do not send these. Do not number figures.

 RULES THAT APPLY EVERYWHERE
   1. Every number in your text must also be in the data workbook (or the
      StatCompiler file), with its year and source. A number with no source
      is sent back.
   2. Cite in the text as (Author, Year), for example (WHO, 2025) or
      (Kiuru et al., 2025). Write "WHO", never "WMR". Every citation must
      appear in the references table in Section 11.
   3. Name surveys one way: "2022-23 DHS", "2018 MIS", "2015 AIS". Give the
      local name once in brackets, for example "2022-23 DHS (IDS)". Spell out
      every acronym at first use.
   4. Write in English. Put local-language terms in italics with a
      translation. Save this file as UTF-8 and check that accents display
      correctly (for example Zambezia).
   5. Do not edit .qmd files. Do not rename headings or delete the
      DET-FIGURE lines.
   6. Do not type facility counts, shares or densities in Section 7. DET writes
      those sentences from your Facilities tab.

 HOW TO ADD A FIGURE YOU SUPPLY (only in Sections 8 and 9)
   Three lines per figure, a blank line between figures. Do not write a
   figure number. DET adds it.

     ![](Images/short_descriptive_name.png)
     **Figure:** What it shows, the unit and the years.
     **Source:** Author or organisation, year, title, link.

   Image files: PNG, lowercase letters, numbers and underscores only, at
   least 1600 pixels wide, white background, no title inside the image,
   English legend, years and units labelled. Put them in the Images folder.
   If a figure comes from a published paper, add "Licence:" with the licence
   or the permission you hold.
==========================================================================
-->

# [Country Name] Country Profile Content

**Prepared by:** [Your name]
**Date:** [YYYY-MM-DD]

---

## 1. Introduction

<!-- YOU WRITE: 3 to 5 sentences. Where the country sits, population,
     why malaria control matters here. -->

[ ]

---

## 2. Summary Statistics

<!-- YOU WRITE: nothing here.
     DET BUILDS: the summary table from the Data tab (rows with Types = KCI). -->

---

## 3. Administrative Boundaries

<!-- YOU WRITE: 2 to 3 sentences. The administrative tiers, how many units at
     each level, and which level is used for health planning. Tell DET the
     local names of the levels (for example Admin 1 = Province, Admin 2 =
     District) under "Anything else DET should know" at the end.
     DET BUILDS: the administrative map from MAP boundary data. -->

[ ]

<!-- DET-FIGURE: admin-map -->

---

## 4. Malaria Situation

<!-- YOU WRITE: 3 to 5 sentences. Cases, deaths, share of regional or global
     burden, recent trend and main threats. Cite as (WHO, 2025). -->

[ ]

---

## 5. History of Malaria

<!-- YOU WRITE: 3 to 5 sentences on the last 20 years: key interventions,
     policy changes and the current intervention mix.
     DET BUILDS: the timeline from the Timeline tab. Do not send a timeline image. -->

[ ]

<!-- DET-FIGURE: timeline -->

---

## 6. Malaria Indicator Summary

### 6a. DHIS2-derived indicators

<!-- YOU WRITE: 2 to 3 sentences interpreting the routine data (trend,
     completeness, anything unusual). No table.
     DET BUILDS: the table from the Data tab (rows with Types = DHIS2). -->

[ ]

### 6b. Survey-derived indicators

<!-- YOU WRITE: 2 to 3 sentences interpreting the survey results (what changed
     between surveys). No table.
     DET BUILDS: the survey table from your raw StatCompiler export. -->

[ ]

---

## 7. Health System

<!-- YOU WRITE: 3 to 5 sentences. How the health system is organised:
     administrative levels, service levels and referral. Use the same level
     names as in the Health_system tab. Then, if you wish, one short
     paragraph on community health workers.
     DET BUILDS: the health system pyramid (from the Health_system tab) and
     the facility chart and map (from the Facilities tab), with their captions
     and the sentences about facility numbers. -->

[ ]

<!-- DET-FIGURE: health-system -->

**Community health workers (optional):** [ ]

### Geographic location of health facilities

<!-- DET-FIGURE: facility-map -->

<!-- DET-FIGURE: facility-rank -->

---

## 8. Stratification Maps / SNT

<!-- YOU WRITE: 2 to 3 sentences. How stratification has changed over time,
     the variable and level used (for example incidence per 1,000 at district
     level), and which intervention package is currently in use.
     YOU SEND: the stratification or intervention package map(s) as images,
     using the three-line figure block described at the top of this file. -->

[ ]

![](Images/[filename].png)
**Figure:** [ ]
**Source:** [ ]

---

## 9. Environment and Seasonality

<!-- YOU WRITE: 3 to 4 sentences. The ecological drivers, the transmission
     season (months) and what causes it, including extreme weather.
     YOU SEND: the rainfall, temperature or seasonality figures as images,
     using the three-line figure block at the top of this file. -->

[ ]

![](Images/[filename].png)
**Figure:** [ ]
**Source:** [ ]

---

## 10. Vector Profile

<!-- YOU WRITE: 3 to 4 sentences on the main vector species, where each one
     occurs, and insecticide resistance. Cite every study (Author et al., Year).
     DET BUILDS: the vector distribution maps (from MAP surfaces).
     YOU TYPE: the two tables below, one row per finding. Use a public link
     or DOI for every source. A standard Excel format for these tables is
     being prepared by DET; until then, type them here. -->

[ ]

<!-- DET-FIGURE: vectors -->

### Table 9a. Insecticide susceptibility of malaria vectors

| Year of collection | Species | Insecticide (class) | Result | Sites | Source |
|:---|:---|:---|:---|:---|:---|
| [2021-22] | [*An. funestus* s.l.] | [Deltamethrin (pyrethroid)] | [14% mortality, resistant] | [District, Province] | [Author et al. (Year)] |

### Table 9b. Resistance mechanisms

| Year | Species | Finding | Sites | Source |
|:---|:---|:---|:---|:---|
| [2021-22] | [*An. funestus* s.l.] | [PBO pre-exposure raised deltamethrin mortality from 8% to 80%] | [District, Province] | [Author et al. (Year)] |

---

## 11. References

<!-- YOU WRITE: one row per reference. DET groups them by Tag, numbers them and
     adds the data sources it used for its own figures.
       Title:       include the first author and year for papers, for example
                    "Kiuru et al. (2025) Multiple insecticide resistance in Anopheles funestus"
       URL:         a public link or DOI. Not a private Google Drive link.
       Description: one plain sentence on what you used it for.
       Tag:         one of Epidemiology, Intervention, Policy/Strategic Plan,
                    Health System, Vector Bionomics, Resistance
     Do not list the boundary data, facility list or vector maps here. DET adds
     those. -->

| Title | URL | Description | Tag |
|:---|:---|:---|:---|
| [ ] | [ ] | [ ] | [ ] |

---

## Anything else DET should know

<!-- Optional: local names of the administrative levels, data gaps, doubts
     about a number, questions. -->

[ ]
