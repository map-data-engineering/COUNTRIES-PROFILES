<!--
==========================================================================
 COUNTRY PROFILE: CONTENT FILE (version 3)
==========================================================================
 Rename this file to profile_<country>.md (for example profile_mozambique.md).
 Keep the section headings and the lines that start with
 "<!-- DET-FIGURE" exactly as they are. DET maps each heading to a fixed
 place on the page and fills the figure lines by script.

 WHAT YOU DO, AND WHAT DET DOES
   You write:  short narrative text for each section, and the references table.
   You send:   the data workbook (epi_table_<country>.xlsx), the raw DHS
               StatCompiler export, and images only where a section says so.
   DET builds: the summary tables, the administrative map, the timeline, the
               health system diagram, the facility charts and map, and the
               vector distribution map. Do not send these. Do not number figures.

 RULES THAT APPLY EVERYWHERE
   1. Every number in your text must also be in the data workbook (or the
      StatCompiler file), with its year and source. A number with no source
      is sent back.
   2. Cite in the text as (Author, Year), for example (WHO, 2025) or
      (Kiuru et al., 2025). Write "WHO", never "WMR". Every citation must
      appear in the references table in Section 11.
   3. Name surveys one way: "2022-23 DHS", "2018 MIS", "2015 AIS". Give the
      local name once in brackets, for example "2022-23 DHS (IDS)". Spell out
      every acronym at first use.
   4. Write in English. Put local-language terms in italics with a
      translation. Save this file as UTF-8 and check that accents display
      correctly (for example Zambezia).
   5. Do not edit .qmd files. Do not rename headings or delete the
      DET-FIGURE lines.
   6. Do not type facility counts, shares or densities in Section 7. DET writes
      those sentences from your Facilities tab.

 HOW TO ADD A FIGURE YOU SUPPLY (only in Sections 8 and 9)
   Three lines per figure, a blank line between figures. Do not write a
   figure number. DET adds it.

     ![](Images/short_descriptive_name.png)
     **Figure:** What it shows, the unit and the years.
     **Source:** Author or organisation, year, title, link.

   Image files: PNG, lowercase letters, numbers and underscores only, at
   least 1600 pixels wide, white background, no title inside the image,
   English legend, years and units labelled. Put them in the Images folder.
   If a figure comes from a published paper, add "Licence:" with the licence
   or the permission you hold.
==========================================================================
-->

# Uganda Country Profile Content

**Prepared by:** Edmund Steven Kanjagaile
**Date:** 2026-10-20

---

## 1. Introduction

<!-- YOU WRITE: 3 to 5 sentences. Where the country sits, population,
     why malaria control matters here. -->

Uganda is a landlocked East Afrian nation in the WHO African Region, bordered by Kenya, South Sudan, the Democratic Republic of the Congo, Rwanda, and Tanzania. With a population of approximately 45.9 million of 2024 (National Census, 2024) and 51.4 million of 2025 (World Bank projection, 2026), the entire country falls within high-transmission malaria zones (>1 case per 1,000 population), and Plasmodium falciparum accounts for essentially 100% of infections. Malaria control remains a national priority because the disease is Uganda's leading cause of morbidity and mortality driving an estimated 13.2 million cases and over 16,000 deaths annually (WHO, 2025), with the heaviest burden falling on children under five and pregnant women.

---

## 2. Summary Statistics

<!-- YOU WRITE: nothing here.
     DET BUILDS: the summary table from the Data tab (rows with Types = KCI). -->
---

## 3. Administrative Boundaries

<!-- YOU WRITE: 2 to 3 sentences. The administrative tiers, how many units at
     each level, and which level is used for health planning. Tell DET the
     local names of the levels (for example Admin 1 = Province, Admin 2 =
     District) under "Anything else DET should know" at the end.
     DET BUILDS: the administrative map from MAP boundary data. -->

Uganda is a landlocked country in the Great Lakes region of East and Central Africa, located between latitudes 1.5°S and 4.2°N and longitudes 29.6°E and 35.0°E. It shares Lake Victoria with Kenya and Tanzania, and Lakes Albert and Edward with the Democratic Republic of Congo. Its total area is *241,550.7 km²*, with 43.6% agricultural land, 21.1% grassland, 15.3% open water, 8.2% bushland, 8.1% forest, 3.2% wetlands, and 0.6% built-up areas (UMRESP, 2023; UBOS, 2018). The climate is equatorial, moderated by an elevation of 1,200–1,600 m above sea level. Temperatures range from 20 to 30°C, and most of the country has two rainy seasons, a pattern that is shifting with climate change. Uganda is divided into 4 regions, 17 sub-regions, and 135 districts, 11 cities, 302 counties, 31 Municipalities, 2197 sub-counties, 10717 Parishes, and 71,227 villages (UBOS, 2026).


<!-- DET-FIGURE: admin-map -->

---

## 4. Malaria Situation

<!-- YOU WRITE: 3 to 5 sentences. Cases, deaths, share of regional or global
     burden, recent trend and main threats. Cite as (WHO, 2025). -->

In 2024, Uganda accounted for 4.7% of all malaria cases and 2.7% of all deaths worldwide (WHO, 2025). It is one of five countries (Nigeria, DRC, Ethiopia, and Mozambique) that together account for almost half of global cases. It is also one of the 11 High Burden to High Impact countries, which together carry 64% of the global malaria burden (WHO, 2025). Malaria accounts for an estimated 30–50% of outpatient visits and 15–20% of hospital admissions in Uganda (MoH, 2024). In 2024, the national programme reported 13.3 million cases, 12.7 million of them confirmed. WHO’s modelled estimate for the same year is 13.2 million cases and 16,204 deaths, compared with 2,793 malaria deaths recorded in health facilities in 2023 (WHO, 2025). Progress is uneven, reported confirmed cases fell 20% between 2023 and 2024, yet WHO’s estimated cases and deaths each rose about 1.5%, and estimated incidence has fallen only 8.5% since 2015. The main threats are resurgence where indoor spraying is withdrawn, as seen in northern Uganda after 2014. Other threats include mosquito resistance to pyrethroids, emerging partial artemisinin resistance in parasites, climate-driven epidemics (over 40 districts in 2021–22), and the health needs of more than 1.5 million refugees (WHO., 2025; PMI., 2023).

---

## 5. History of Malaria

<!-- YOU WRITE: 3 to 5 sentences on the last 20 years: key interventions,
     policy changes and the current intervention mix.
     DET BUILDS: the timeline from the Timeline tab. Do not send a timeline image. -->

Organised malaria control in Uganda began with a WHO–Ministry of Health eradication pilot in northern Kigezi (1959–64), which combined indoor residual spraying (IRS) using dichlorodiphenyltrichloroethane (DDT) with mass drug administration (MDA) and cut parasite prevalence in children from 16.6% to 0.3%; field trials of DDT, dieldrin and malathion in Masaka followed in the early 1960s (NMCP, 2013; Cullen & de Zulueta, 1964; Talisuna et al., 2015). These gains were lost during two decades of civil strife and war from the 1970s, which caused the health system to collapse, until the Ministry of Health set up a Malaria Control Unit in 1995 and raised it to a National Malaria Control Programme (NMCP) in 2001 (Dodge, 1986; MoH, 2014). First-line treatment moved from chloroquine to chloroquine plus sulfadoxine–pyrimethamine in 2000 and then to artemether–lumefantrine in 2004, while long-lasting insecticidal nets, expanded IRS, rapid diagnostic tests (RDT) under a 2011 test-before-treatment policy, and nationwide DHIS2 reporting from 2012 were scaled up (MoH., 2011; MoH., 2014; Kiberu et al., 2014). More recently, seasonal malaria chemoprevention was launched in Karamoja in 2022, and the R21/Matrix-M vaccine was introduced in 105 districts in April 2025 (FCU-GF, 2022; WHO AFRO, 2025). In April 2026, the Ministry of Health launched the Uganda Malaria Radication and Elimination Strategic Plan (UMRESP) 2026–2030, formally shifting the programme from control to elimination with a goal of zero malaria deaths by 2030 (MoH., 2026; NMED, 2026).

<!-- DET-FIGURE: timeline -->

---

## 6. Malaria Indicator Summary

### 6a. DHIS2-derived indicators

<!-- YOU WRITE: 2 to 3 sentences interpreting the routine data (trend,
     completeness, anything unusual). No table.
     DET BUILDS: the table from the Data tab (rows with Types = DHIS2). -->

The section presents malaria surveillance indicators reported through the District Health Information System 2 (DHIS2) up to 2022, as compiled in the U.S. President's Malaria Initiative (PMI) Uganda Malaria Profile. The indicators are all-cause outpatient consultations, suspected malaria cases, patients receiving a diagnostic test, confirmed and presumed malaria cases, malaria cases in children under five years, severe malaria cases, malaria deaths, and the number of community health workers (CHWs).

### 6b. Survey-derived indicators

<!-- YOU WRITE: 2 to 3 sentences interpreting the survey results (what changed
     between surveys). No table.
     DET BUILDS: the survey table from your raw StatCompiler export. -->

The section presents national malaria indicators from nationally representative household surveys: the Uganda Demographic and Health Surveys (UDHS) of 2006 and 2011, and the Uganda Malaria Indicator Surveys (UMIS) of 2009, 2014–15, 2018–19 and 2024–25. Unlike routine facility data, these surveys capture malaria in the whole population, so they show changes in parasite prevalence, intervention coverage and child mortality over time.

---

## 7. Health System

<!-- YOU WRITE: 3 to 5 sentences. How the health system is organised:
     administrative levels, service levels and referral. Use the same level
     names as in the Health_system tab. Then, if you wish, one short
     paragraph on community health workers.
     DET BUILDS: the health system pyramid (from the Health_system tab) and
     the facility chart and map (from the Facilities tab), with their captions
     and the sentences about facility numbers. -->

Uganda, there are 7143 health facilities established under unique administrative units, running a mixed health system of public, private and traditional providers, with six levels of care. At the top are 9 National Referral Hospitals and 16 Regional Referral Hospitals (Uganda National Health Facility Registry (UNHFR), 2026). The district health system beneath them (UMRESP, 2021-2025). Management runs through the same levels, from the Ministry of Health through the regional, district and health sub-district teams to the VHTs, while patients are referred upward from community-level care to the higher facilities.

<!-- DET-FIGURE: health-system -->

**Community health workers:** Health data in Uganda start at the community level, where Community Health Workers (CHWs), known as Village Health Teams (VHTs), record the malaria cases they test and treat through integrated Community Case Management (iCCM) and report monthly to their supervising health facility. Facilities compile these with their own records into weekly surveillance (IDSR) and monthly HMIS reports, which districts validate in DHIS2 before the Ministry of Health's Division of Health Information hosts them and the National Malaria Control Division (NMCD) extracts the malaria data into its national data repository (MoH, 2021). The analysed information flows back down to districts, facilities and communities through reports, bulletins and review meetings to guide decisions.


### Geographic location of health facilities

<!-- DET-FIGURE: facility-map -->

<!-- DET-FIGURE: facility-rank -->

---

## 8. Stratification Maps / SNT

<!-- YOU WRITE: 2 to 3 sentences. How stratification has changed over time,
     the variable and level used (for example incidence per 1,000 at district
     level), and which intervention package is currently in use.
     YOU SEND: the stratification or intervention package map(s) as images,
     using the three-line figure block described at the top of this file. -->

Uganda's malaria stratification began with the INFORM map, which classified all 135 districts into five bands based only on modelled parasite prevalence in children aged 2–10 years (PfPR₂₋₁₀) (Alegana et al., 2021). For the UMRESP 2021–2025, the NMCD used the WHO High Burden to High Impact method in two steps: it first stratified districts by parasite prevalence (MIS, 2018), malaria incidence (HMIS, 2019), and under-5 mortality (2017), and then overlaid seasonality, urbanisation and access to care to assign an intervention mix to each district using WHO decision criteria (MoH, 2020). At the end of that plan, the 2025 Malaria Programme Review combined four district indicators into a single composite risk score: adjusted incidence from routine DHIS2 data, parasite prevalence, severe-malaria admissions and under-5 mortality. It then grouped districts into five equal-width bands; very low (≤11), low (11–22), moderate (22–33), high (33–44), and very high (>44) (MoH/NMED, 2025). The Elimination Strategic Plan 2026–2030 adopted this five-category map and added a three-tier intervention layer that groups all 146 districts and cities by incidence and prevalence into Zone 1 (high burden, northern Uganda), Zone 2 (moderate, central belt) and Zone 3 (low, south-west and Kampala). It also commits to updating the stratification every two years and moving to sub-county, parish, and village levels (MoH/NMED, 2026).

![**Figure:**](<C:\Users\ekanjagaile\Desktop\Country_Profile\Uganda\country-submission-template\Images\uganda_risk_strata_combined.png>)
**Figure 7:** Malaria Epidemiological Stratification Map

**Source:** A. UMRESP (2021-2025), B. Malaria Programme Review Report-2025

---

## 9. Environment and Seasonality

<!-- YOU WRITE: 3 to 4 sentences. The ecological drivers, the transmission
     season (months) and what causes it, including extreme weather.
     YOU SEND: the rainfall, temperature or seasonality figures as images,
     using the three-line figure block at the top of this file. -->

The equatorial climate features temperatures (20–30 °C) and rainfall (500–2,800 mm) that sustain stable malaria transmission across ~95% of the country, while the highlands and semi-arid areas are increasingly prone to epidemics (Malaria Program Review, 2025). About 95% of Uganda has stable, year-round malaria transmission, sustained by wetlands, lakes and river systems in lowlands below about 1,200 m that provide perennial breeding sites for *Anopheles* mosquitoes; the remaining 5%, chiefly the cooler south-western highlands, has unstable transmission and is prone to epidemics (UMRESP, 2021–2025; PMI Uganda Malaria Profile 2023; UMESP, 2026–2030). *Figure 14* Shows mean monthly rainfall throughout the regions from 2001 to 2020.

![**Figure:**](<C:\Users\ekanjagaile\Desktop\Country_Profile\Uganda\country-submission-template\Images\uganda_rainfall_seasonality.png>)
**Figure 14:** Mean monthly rainfall (mm) by region, Uganda, 2001–2020

**Source:** CHIRPS v3.0 (Climate Hazards Center, UC Santa Barbara), 0.05°, monthly totals Jan 2001–Dec 2020, averaged over each region's land area (lakes excluded); https://www.chc.ucsb.edu/data/chirps3

Temperature permits transmission almost everywhere: mean annual temperature ranges from 21.1 °C in Ankole to 25.7 °C in Madi and falls to 18–19 °C only in the highland sub-regions of Sebei, Kigezi and Bugisu *(Figure 15)*.

![**Figure:**](<C:\Users\ekanjagaile\Desktop\Country_Profile\Uganda\country-submission-template\Images\uganda_temperature_seasonality.png>)
**Figure 15:** Mean monthly temperature (°C) by region, Uganda, 2001–2020

**Source:** ERA5-Land monthly averaged reanalysis, 2 m temperature (Copernicus Climate Change Service), 0.1°, Jan 2001–Dec 2020, averaged over each region's land area; https://cds.climate.copernicus.eu/datasets/reanalysis-era5-land-monthly-means (doi:10.24381/cds.68d2bb30)

Rainfall therefore sets the timing: the Central, Eastern and Western regions have two rainy seasons, March–May and September–December, with a transmission peak after each, while the north has a single rainy season, running from April to October in the far north-east, and Northern Region rainfall rises from 18 mm in January to 176 mm in August (UMRESP, 2021–2025; UMESP, 2026–2030; *Figure 16*). Increasingly erratic rainfall, floods, and rising temperatures are pushing malaria into areas of historically low or unstable transmission, particularly the highlands, as in the 2021–2022 epidemic that affected 40 districts, including Kigezi and indoor residual spraying (IRS) districts in the east (PMI Uganda Malaria Profile, 2023; UMESP, 2026–2030).


![**Figure:**](<C:\Users\ekanjagaile\Desktop\Country_Profile\Uganda\country-submission-template\Images\uganda_climate_maps.png>)
**Figure 16:** Climate zones, mean annual rainfall and temperature by sub-region, Uganda

**Source:** Rainfall: CHIRPS v3.0 (Climate Hazards Center, UC Santa Barbara), 0.05°; temperature: ERA5-Land (Copernicus Climate Change Service), 0.1°; monthly data Jan 2001–Dec 2020, sub-region land-area means with lakes excluded

---

## 10. Vector Profile

<!-- YOU WRITE: 3 to 4 sentences on the main vector species, where each one
     occurs, and insecticide resistance. Cite every study (Author et al., Year).
     DET BUILDS: the vector distribution maps (from MAP surfaces).
     YOU TYPE: the two tables below, one row per finding. Use a public link
     or DOI for every source. A standard Excel format for these tables is
     being prepared by DET; until then, type them here. -->

Malaria in Uganda is transmitted mainly by *Anopheles gambiae* s.s., *An. arabiensis* and *An. funestus* in *Figure 18* Vector Atlas models give *An. gambiae* s.s. the highest probability of occurrence in 11 of the 17 sub-regions and *An. arabiensis* in the other six (the five Eastern sub-regions and Karamoja) (Ryan et al., 2026), a balance that vector control can shift, as in Tororo, where LLINs and indoor residual spraying turned a vector population that was 77% *An. gambiae* s.s. into one that was 99.5% *An. arabiensis* (Musiime et al., 2019). 

<!-- DET-FIGURE: vectors -->

### Table 9a. Insecticide susceptibility of malaria vectors

| Year of collection | Species | Insecticide (class) | Result | Sites | Source |
|:---|:---|:---|:---|:---|:---|
| [2021-22] | [*An. funestus* s.l.] | [Deltamethrin (pyrethroid)] | [14% mortality, resistant] | [District, Province] | [Author et al. (Year)] |

### Table 9b. Resistance mechanisms

Insecticide resistance in Uganda's malaria vectors works through two mechanisms: *kdr mutations* that alter the insecticide's target site, and metabolic resistance, in which over-expressed enzymes such as *cytochrome P450s* break the insecticide down (Table 5). An. gambiae s.s. carries both, with the kdr mutation Vgsc-L1014S near fixation, whereas resistance in An. funestus is metabolic and driven by P450 genes (Lynd et al., 2019; Mulamba et al., 2014; Oruni et al., 2024). PBO only partly restores susceptibility at some sites, and the first Ugandan detection of Ace1 and Rdl resistance alleles in 2021–23 signals emerging resistance to other insecticide classes (Okia et al., 2018; Oruni et al., 2024)

**Table 5:** Insecticide resistance mechanisms in Ugandan malaria vectors, 2009–2023 ·

| Year | Species | Finding | Sites | Source |
|---|---|---|---|---|
| 2009 | *An. funestus* | No L1014F *kdr* mutation detected; target-site resistance not the cause | Tororo | Morgan et al. (2010) |
| 2009 | *An. funestus* | Elevated GST, P450 and esterase activity; *CYP6P9b* over-expressed 12-fold | Tororo | Morgan et al. (2010) |
| 2011–12 | *An. funestus* | No resistance-associated *kdr* mutation (F1021C present but not linked to resistance) | Bulambuli, Jinja, Lira, Tororo | Mulamba et al. (2014) |
| 2011–12 | *An. funestus* | Synergist assays and qRT-PCR: pyrethroid resistance driven by elevated cytochrome P450 expression | Arua, Bulambuli, Jinja, Lira, Masindi, Tororo | Mulamba et al. (2014) |
| 2011–12 | *An. funestus* | L119F-*GSTe2* explains only a small share of DDT resistance | Arua, Bulambuli, Jinja, Lira, Masindi, Tororo | Mulamba et al. (2014) |
| 2015 | *An. gambiae* s.l. | PBO pre-exposure restored permethrin and deltamethrin efficacy (oxidase-mediated) | Soroti, Tororo | Okia et al. (2018) |
| 2015 | *An. gambiae* s.l. | PBO only partly restored susceptibility (deltamethrin in Lira, permethrin in Apac): oxidases plus other mechanisms | Apac, Lira | Okia et al. (2018) |
| 2017–18 | *An. gambiae* s.s. | *kdr* Vgsc-L1014S at very high frequency, L1014F low, wild-type allele virtually absent | 104 health sub-districts, 48 districts | Lynd et al. (2019) |
| 2017–18 | *An. arabiensis* | Wild-type (susceptible) Vgsc allele predominant | 104 health sub-districts, 48 districts | Lynd et al. (2019) |
| 2017–18 | *An. gambiae* s.s. | *Cyp4j5*-L43F (P450) allele frequency 0.60 and *Coeae1d* (esterase) 0.54 overall, varying by site; Vgsc-N1575Y absent | 104 health sub-districts, 48 districts | Lynd et al. (2019) |
| 2017–19 | *An. gambiae* s.s. | Pyrethroid-resistance marker frequencies rose during LLIN deployment; Vgsc-995S (L1014S) declined as Vgsc-995F (L1014F) increased, suggesting 995F is spreading into Uganda | 104 health sub-districts, 48 districts | Lynd et al. (2024) |
| 2021–23 | *An. funestus* s.s. | PBO pre-exposure gave only partial recovery of pyrethroid susceptibility | Mayuge | Oruni et al. (2024) |
| 2021–23 | *An. funestus* s.s. | *CYP9K1* resistance allele at consistently very high frequency; *CYP6P9a/b* alleles very low | Mayuge | Oruni et al. (2024) |
| 2021–23 | *An. funestus* s.s. | *CYP9K1*, *CYP6P9a*, *CYP6P9b*, *CYP6P5* and *CYP6M7* consistently over-expressed; *GSTe2* expression low | Mayuge | Oruni et al. (2024) |
| 2021–23 | *An. funestus* s.s. | First detection in Uganda of *Ace1* (RS ≈ 13%) and *Rdl* (RS ≈ 21%, RR ≈ 4%) resistance alleles | Mayuge | Oruni et al. (2024) |
---

## 11. References

<!-- YOU WRITE: one row per reference. DET groups them by Tag, numbers them and
     adds the data sources it used for its own figures.
       Title:       include the first author and year for papers, for example
                    "Kiuru et al. (2025) Multiple insecticide resistance in Anopheles funestus"
       URL:         a public link or DOI. Not a private Google Drive link.
       Description: one plain sentence on what you used it for.
       Tag:         one of Epidemiology, Intervention, Policy/Strategic Plan,
                    Health System, Vector Bionomics, Resistance
     Do not list the boundary data, facility list or vector maps here. DET adds
     those. -->

| Title | URL | Description | Tag |
|---|---|---|---|
| World Bank Open Data: Uganda | https://data.worldbank.org/country/uganda | Population 2025, 51.4 million (Section 1, Table 1) | Epidemiology |
| Uganda Bureau of Statistics. National Population and Housing Census (NPHC) 2024 | https://statistics.ubos.org/nphc/ | Census population 45,905,417 (Section 1) | Epidemiology |
| WHO. World Malaria Report 2025 | https://www.who.int/publications/i/item/9789240117822 | Incidence 2024 (Table 1); estimated cases and deaths, share of global burden, HBHI status (Sections 1 and 4) | Epidemiology |
| WHO. Malaria 2025 Uganda country profile | https://www.who.int/publications/m/item/malaria-2025-uganda-country-profile | Population at risk 46.9 million, all in high-transmission areas; *P. falciparum* 100% (Section 1, Table 1) | Epidemiology |
| WHO Global Health Observatory. Malaria mortality rate (per 100,000 population), estimate | https://www.who.int/data/gho/data/indicators/indicator-details/GHO/estimated-malaria-mortality-rate-per-100-000-population | Malaria mortality 32.4 per 100,000, 2024 (Table 1) | Epidemiology |
| ICF. The DHS Program STATcompiler | https://www.statcompiler.com/en/ | DHS and MIS indicators 1988–89 to 2024–25 (Tables 1 and 3); sub-regional malaria prevalence and ITN use across surveys (Figures 10–13, 20–21) | Epidemiology |
| UBOS and ICF. Uganda Malaria Indicator Survey 2024–25: Final Report (2026) | https://www.dhsprogram.com/pubs/pdf/MIS45/MIS45.pdf | Malaria prevalence in children aged 6–59 months, 21.1% by RDT and 12.5% by microscopy (Table 1, Section 8); districts making up the 15 survey sub-regions mapped in Figures 10–13 and 20–21 | Epidemiology |
| Uganda administrative boundaries from the 2024 NPHC (has2k1/uganda-boundaries) | https://github.com/has2k1/uganda-boundaries | Region, sub-region and district boundaries (Figure 1); base map for the sub-regional maps (Figures 10–13, 20–21) | Health System |
| OCHA / Uganda Bureau of Statistics. Uganda – Subnational Administrative Boundaries (COD-AB) | https://data.humdata.org/dataset/cod-ab-uga | Version 01 counts of regions, districts, counties and sub-counties (Section 3); reflects the 135-district system | Health System |
| National Malaria Control Programme and the INFORM Project. An epidemiological profile of malaria and its control in Uganda (2013) | https://inform.kemri-wellcome.org/wp-content/uploads/2021/06/Uganda-INFORM-Epi-Profile-2013-1.pdf | History of malaria control, including the northern Kigezi eradication pilot (1959–64) and the Masaka field trials (Section 5) | Epidemiology |
| Cullen JR, de Zulueta J. Observations on the effect of residual insecticides in experimental huts in Masaka District, Uganda (1964) | https://pmc.ncbi.nlm.nih.gov/articles/PMC2554811/ | Bull World Health Organ 30(2):263–278; DDT and dieldrin trials in Masaka (Section 5) | Intervention |
| Talisuna AO, Noor AM, Okui AP, Snow RW. The past, present and future use of epidemiological intelligence to plan malaria vector control and parasite prevention in Uganda (2015) | https://doi.org/10.1186/s12936-015-0677-4 | Review of IRS, mass drug administration and other control in Uganda, 1900–2013 (Section 5, Figure 2) | Intervention |
| Dodge CP. Uganda – rehabilitation, or redefinition of health services? (1986) | https://ideas.repec.org/a/eee/socmed/v22y1986i7p755-761.html | Soc Sci Med 22(7):755–761; collapse of health services after the 1970s conflict (Section 5) | Health System |
| Ministry of Health. Mid Term Review of the 2010–2015 Malaria Strategic Plan (2014) | https://mesamalaria.org/wp-content/uploads/2026/07/Uganda-Mid-Term-Review-of-the-2010-%E2%80%93-2015-Malaria-Strategic-Plan.pdf | NMCP inception in 1995; scale-up of LLINs, IRS, RDTs and DHIS2 reporting (Section 5) | Policy/Strategic Plan |
| Yeka A et al. Malaria in Uganda: challenges to control on the long road to elimination: I. Epidemiology and current control efforts (2012) | https://doi.org/10.1016/j.actatropica.2011.03.004 | History of malaria control and policy changes (Section 5, Figure 2) | Epidemiology |
| Kiberu VM et al. Strengthening district-based health reporting through the district health management information software system: the Ugandan experience (2014) | https://doi.org/10.1186/1472-6947-14-40 | National DHIS2 roll-out (Section 5, Figure 2) | Health System |
| Okullo AE et al. Malaria incidence among children less than 5 years during and after cessation of indoor residual spraying in Northern Uganda (2017) | https://doi.org/10.1186/s12936-017-1966-x | Resurgence after IRS was withdrawn in northern Uganda (Section 4, Figure 2) | Intervention |
| WHO Regional Office for Africa. Uganda launches largest malaria vaccine introduction to date (2025) | https://www.afro.who.int/countries/uganda/news/uganda-launches-largest-malaria-vaccine-introduction-date | R21/Matrix-M vaccine introduced in 105 districts, 2 April 2025 (Section 5, Figure 2) | Intervention |
| PMI Uganda Malaria Profile (FY 2024, updated 31 May 2023) | https://mesamalaria.org/wp-content/uploads/2025/04/UGANDA-Malaria-Profile-PMI-FY-2024.pdf | MoH DHIS2 indicators 2018–2022 (Table 2); UMRESP strata (Section 8); stable vs unstable transmission and the 2021–22 epidemic in 40 districts (Sections 4 and 9) | Epidemiology |
| Uganda Malaria Reduction and Elimination Strategic Plan (UMRESP) 2021–2025 | https://health.go.ug/wp-content/uploads/2025/01/MALARIA-REDUCTION-AND-ELIMINATION-STRATEGIC-PLAN-2021-2025.pdf | Land cover (Section 3); district health system and data flow (Section 7, Figure 4); 2020 district stratification (Section 8, Figure 7); rainy seasons, 95% stable / 5% unstable transmission (Section 9) | Policy/Strategic Plan |
| Ministry of Health (MoH). Uganda National Health Facility Registry | https://nhfr.health.go.ug/ | Facilities by level of care and health region (Section 7, Figures 3 and 5) | Health System |
| HealthScope health facility registry | https://map-data-engineering.github.io/healthscope-portal/registry.html | Geolocated facilities by level of care and ownership (Section 7, Figure 7) | Health System |
| Alegana VA et al. Plasmodium falciparum parasite prevalence in East Africa: updating data for malaria stratification (2021) | https://doi.org/10.1371/journal.pgph.0000014 | Modelled PfPR2–10 behind the 2019 district stratification (Section 8) | Epidemiology |
| Ministry of Health / NMED. Uganda Malaria Programme Review Report (August 2025) | Not yet published online (Ministry of Health, Uganda) | Composite district risk score and five-band stratification (Section 8, Figure 7B); incidence 2020–2024 (Figure 8); PfPR 2020 and 2024 (Figure 9); climate and transmission (Section 9) | Policy/Strategic Plan |
| Uganda Malaria Elimination Strategic Plan (UMESP) 2026–2030 | https://mesamalaria.org/wp-content/uploads/2026/06/Uganda-Malaria-Elimination-Strategic-Plan-UMESP-2026%E2%80%932030.pdf | Shift from control to elimination, April 2026 (Section 5); five-band stratification and three intervention zones (Section 8); ecological zones, bimodal rainfall, altitude (<1,200 m) and climate variability as transmission drivers (Section 9) | Policy/Strategic Plan |
| CHIRPS v3.0, Climate Hazards Center, UC Santa Barbara | https://www.chc.ucsb.edu/data/chirps3 | Monthly rainfall 2001–2020 at 0.05° (Figures 14 and 16) | Epidemiology |
| ERA5-Land monthly averaged reanalysis, Copernicus C3S | https://doi.org/10.24381/cds.68d2bb30 | Monthly 2 m temperature 2001–2020 at 0.1° (Figures 15 and 16) | Epidemiology |
| Ninsiima LR et al. Climate variability and malaria incidence trends in Yumbe District, West Nile Sub-region of Uganda (2017–2021) (2026) | https://doi.org/10.1186/s12936-026-05824-0 | Malaria cases tracking rainfall in Yumbe District (Figure 17) | Epidemiology |
| Ryan G, Sinka M, Golding N. Vector Atlas Species Abundance and Distribution Maps (2026) | https://doi.org/10.26188/34044441.v1 | Probability of occurrence for 18 Anopheles species, published 1 Oct 2026; vector distribution map and sub-region species chart (Section 10, Figures 18 and 19) | Vector Bionomics |
| Musiime AK et al. Impact of vector control interventions on malaria transmission intensity, outdoor vector biting rates and Anopheles mosquito species composition in Tororo, Uganda (2019) | https://doi.org/10.1186/s12936-019-3076-4 | LLINs plus six IRS rounds shifted the vectors from 77% An. gambiae s.s. to 99.5% An. arabiensis (2011–12 vs 2017–18) (Section 10) | Vector Bionomics |
| Staedke SG et al. Effect of long-lasting insecticidal nets with and without piperonyl butoxide on malaria indicators in Uganda (LLINEUP): a pragmatic, cluster-randomised trial (2020) | https://doi.org/10.1016/S0140-6736(20)30214-2 | National trial in 48 districts; PBO nets reduced parasite prevalence more than conventional nets for 18 months (Section 10) | Intervention |
| Maiteki-Sebuguzi C et al. Effect of long-lasting insecticidal nets with and without piperonyl butoxide on malaria indicators in Uganda (LLINEUP): final results (2023) | https://doi.org/10.1016/S1473-3099(22)00469-8 | 25-month results: parasite prevalence 17.1% with PBO nets vs 19.8% with conventional nets (PR 0.80); rationale for PBO nets (Section 10) | Intervention |
| Lynd A et al. LLIN Evaluation in Uganda Project (LLINEUP): a cross-sectional survey of species diversity and insecticide resistance in 48 districts of Uganda (2019) | https://doi.org/10.1186/s13071-019-3353-7 | Baseline survey, 104 health sub-districts in 48 districts; kdr Vgsc-L1014S at very high frequency in An. gambiae s.s. (Section 10, Table 5) | Resistance |
| Morgan JC et al. Pyrethroid resistance in an Anopheles funestus population from Uganda (2010) | https://doi.org/10.1371/journal.pone.0011872 | Tororo 2009: first report of pyrethroid/DDT resistance in An. funestus from East Africa; no L1014F kdr, CYP6P9b over-expressed 12-fold (Table 5) | Resistance |
| Mulamba C et al. Widespread pyrethroid and DDT resistance in the major malaria vector Anopheles funestus in East Africa is driven by metabolic resistance mechanisms (2014) | https://doi.org/10.1371/journal.pone.0110058 | Six Ugandan districts, 2011–12: P450-driven pyrethroid resistance, no kdr role; carbamates and organophosphates still effective (Section 10, Table 5) | Resistance |
| Okia M et al. Insecticide resistance status of the malaria mosquitoes: Anopheles gambiae and Anopheles funestus in eastern and northern Uganda (2018) | https://doi.org/10.1186/s12936-018-2293-6 | CDC bottle assays, June 2015: PBO restored pyrethroid efficacy in An. gambiae s.l. in Soroti and Tororo, partly in Apac and Lira (Section 10, Table 5) | Resistance |
| Lynd A et al. LLINEUP: effects of a vector control trial on Plasmodium infection prevalence and genotypic markers of insecticide resistance in Anopheles vectors from 48 districts of Uganda (2024) | https://doi.org/10.1038/s41598-024-65050-z | 2017–19: resistance marker frequencies rose; Vgsc-995F increasing and spreading into Uganda (Table 5) | Resistance |
| Oruni A et al. Temporal evolution of insecticide resistance and bionomics in Anopheles funestus, a key malaria vector in Uganda (2024) | https://doi.org/10.1038/s41598-024-83689-6 | Mayuge 2021–23: pyrethroid resistance up to 10× the diagnostic dose, carbamate resistance, full susceptibility to organophosphates and chlorfenapyr; *CYP9K1*, *Ace1* and *Rdl* alleles (Section 10, Table 5) | Resistance |

---

## Anything else DET should know

<!-- Optional: local names of the administrative levels, data gaps, doubts
     about a number, questions. -->

[ ]
