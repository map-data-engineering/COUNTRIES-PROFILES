<!--
  COUNTRY PROFILE — CONTENT FILE
  Rename this file to profile_<yourcountry>.md before submitting
  (e.g. profile_drc.md).

  Fill in every [ ... ] placeholder below and delete the placeholder
  brackets. Leave the section headers exactly as they are — DET maps
  each heading to a fixed spot on the country page.

  GUIDANCE (applies to every table/figure in this file):
  Every statistic, table, and figure MUST include its YEAR and its
  SOURCE. A number or map without a source will be sent back to you
  before it's published — please don't leave this for DET to chase.

  Viewing this file: any Markdown previewer (VS Code, GitHub, a
  browser extension) will render this readably so you can check your
  own work before sending it.
-->

# Burkina-Faso — Country Profile Content

**Prepared by:** Edmond SACLA AIDE, Herieth ALEXANDER 
**Date:** 2026-09-22

---

## 1. Introduction

Burkina Faso is a landlocked country in the West African Sahel, bordered by Mali, Niger, Benin, Togo, Ghana, and Côte d'Ivoire, with a population of roughly 23-24 million (World Bank, 2025). Malaria is endemic countrywide and remains the leading cause of morbidity and mortality nationally, placing the country among the highest-burden nations globally by both incidence and absolute deaths (WHO Global Health Observatory, 2024). This makes a clear, current epidemiological picture essential for guiding the country's malaria control and elimination strategy, particularly given the added complexity of an ongoing security crisis affecting access and service delivery in parts of the country.

---

## 2. Summary Statistics

Country and malaria summary indicators are compiled here from World Malaria Report/WHO Global Health Observatory data, HMIS reporting).
The gap between WHO-estimated deaths (16,146) and HMIS-reported deaths (4,355), roughly 3.7-fold reflects under-ascertainment of malaria mortality in routine facility data: deaths occurring at home, in transit, or outside the formal health system are not captured by HMIS, and WHO's estimation methodology adjusts for this systematically. The "100% population at risk" classification is a national-level simplification; burden is not evenly distributed across the country.

Table 1: Summary statistics
| Indicator | Value | Year | Source |
|---|---|---|---|
| Population | 23.8 million | 2025 | World Bank |
| Population at risk of malaria | Effectively the entire population — Burkina Faso is classified as a high-transmission country countrywide | 2023 | WHO Global Health Observatory / World Malaria Report |
| Malaria incidence — WHO estimated | 353.5 per 1,000 population at risk | 2023–2024 | WHO Global Health Observatory / World Malaria Report |
| Malaria incidence — routine/reported (HMIS) | 12,465,543 reported cases | 2021 | ALMA Scorecard for Accountability and Action |
| Malaria mortality — WHO estimated | 16,146 deaths | 2023 | WHO Global Health Observatory / World Malaria Report |
| Malaria mortality — routine/reported (HMIS) | 4,355 reported deaths | 2021 | ALMA Scorecard for Accountability and Action |
| Capital city | Ouagadougou (capital, largest city); Bobo-Dioulasso (second city) | — | — |
| Economic activities + geography | Agriculture/livestock-based; gold and cotton as principal exports | 2024–2025 | — |

---

## 3. Administrative Boundaries

Burkina Faso comprises 13 regions, subdivided into 45 provinces, further divided into 351 departments/communes. The pre-July 2025 structure still used by essentially all current malaria/health data. The health system is organized separately into 70 health districts, which nest within province boundaries rather than cutting across them (HDX/GRID3, 2023). Note that the administrative structure was redrawn in July 2025, expanding to 17 regions and 47 provinces, so any new analysis should confirm which structure the underlying dataset uses before joining it to older data.

**Figure:** BurkinaFaso_StudyArea_Map
**Caption:** Administrative regions of Burkina Faso, showing the 13 regions and their capitals · 
**Source:** Institut Géographique du Burkina (IGB), via OCHA Humanitarian Data Exchange, 2026.

---

## 4. Malaria Situation

Burkina Faso has one of the highest malaria incidence rates in the world, estimated at 353.5 confirmed cases per 1,000 population at risk (WHO Global Health Observatory, 2024). Parasite prevalence among children 6-59 months stood at 28% by RDT and 14% by microscopy in the most recent national survey (EDSBF-V, INSD, 2021). WHO estimates 16,146 malaria deaths in 2023, substantially higher than the 4,355 deaths captured through routine HMIS reporting in 2021. A gap reflecting under-ascertainment of deaths occurring outside the formal health system (ALMA Scorecard for Accountability and Action, 2023, WHO Global Health Observatory, 2024). Burkina Faso consistently ranks among the world's highest-burden countries for malaria, by both incidence rate and absolute death toll (WHO Global Health Observatory, 2024).

---

## 5. History of Malaria (last 20 years)

Burkina Faso's modern malaria response began scaling in 2010 with the first free mass long-lasting insecticidal net (LLIN) distribution campaign, established on a recurring 3-year replacement cycle (Secrétariat permanent/PNLP, 2023). Seasonal Malaria Chemoprevention (SMC) was introduced in 7 health districts in 2014, the same year malaria surveillance was integrated into DHIS2, with documented data-quality improvements by 2017 (accuracy rising from 43% to 83%) (DHIS2, 2020, PNLP, 2023;). National insecticide resistance monitoring began in 2015, and in 2016 the government adopted a free-healthcare policy (Gratuité) for children under five and pregnant women, piloted in three regions before nationwide rollout within the same year (WHO Regional Office for Africa, 2018). The programme was further formalized in 2019 through adoption of the WHO High Burden High Impact (HBHI) framework, and elevated organizationally in 2022 when the National Malaria Control Programme became the Permanent Secretariat for Malaria Elimination by 2030 (SP/Palu) (PNLP, 2023). The current intervention mix combines LLIN mass campaigns, near-universal SMC coverage, free case management for the highest-risk groups, and as of 2025, malaria vaccination expanded to all 70 health districts nationally (WHO Regional Office for Africa Biennial Report, 2024-2025).

**Figure:** BurkinaFaso_history_timeline
**Caption:** Timeline of key malaria control policy changes in Burkina Faso, 2010–2025
**Source:** Compiled from Secrétariat permanent/PNLP, ALMA Scorecard, DHIS2.org, WHO-AFRO, and INSD survey data (see References)

---

## 6. Malaria Indicator Summary

### 6a. DHIS2-derived indicators (incidence)  
Routine surveillance indicators below are drawn from Burkina Faso's national health information system (SNIS), integrated into DHIS2, and compiled through official Secrétariat permanent/PNLP reporting, WHO Regional Office for Africa publications, and the ALMA Scorecard for Accountability and Action.

Table 2a: DHIS2 routine indicators
| Indicator | Value | Year | Source |
|---|---:|---:|---|
| Confirmed malaria incidence (per 1,000 population) | 451 | 2015 | SNIS/DHIS2 (2022) |
| Confirmed malaria incidence (per 1,000 population) | 569 | 2021 | SNIS/DHIS2, via Secrétariat permanent pour l'élimination du paludisme statement (2022) |
| Total confirmed cases (routine reporting) | 11,915,816 | 2017 | WHO Regional Office for Africa (2018) |
| Total confirmed cases (routine reporting) | 11,567,698 | 2020 | ALMA Scorecard (2023) |
| Total confirmed cases (routine reporting) | 12,465,543 | 2021 | ALMA Scorecard (2023) |
| Total confirmed cases (routine reporting) | 11,656,675 | 2022 | Secrétariat permanent/PNLP (2023) |

### 6b. Survey-derived indicators (prevalence / mortality) - pulled from STATcompilerExport

| Indicator | Value | Year | Source (Survey name) |
|---|---|---|---|
| [ ] | [ ] | [ ] | [ ] |

---

## 7. Health System

Burkina Faso's health system is organized around 70 health districts, the core decentralized planning unit since a 1993 reform each built on two service echelons (CSPS as first-contact facilities, referring to CMA district hospitals), with CHR at the regional level and CHU at the central/tertiary level (Secrétariat permanent/PNLP, 2023). Malaria surveillance data has flowed through DHIS2 since 2014, with a documented data-quality assessment showing accuracy improving from 43% to 83% between the pre-integration baseline and 2017. At the community level, Agents de Santé à Base Communautaire (ASBC), recruited in a wave of over 17,000 in 2016, followed by a further 15,000 ASBC drive launched in 2023 targeting urban Ouagadougou/Bobo-Dioulasso and high-insecurity regions form the frontline tier, financed in part through the Gratuité free-care policy and the broader Stratégie Nationale de Financement de la Santé pour la Couverture Sanitaire Universelle 2017–2030 (Ministry of Health, 2017).

**Figure:** burkina_faso_health_system_pyramid_1600px
**Caption:** Burkina Faso health system - administrative reporting tiers (left) and facility referral tiers
**Source:** Compiled from Secrétariat permanent/PNLP, WHO-AFRO, DHIS2.org, and Ministry of Health data (see References)
---

## 8. Stratification Maps / SNT

[Burkina Faso’s malaria stratification has evolved from national targets under the 2016–2020 National Strategic Plan toward a more explicit subnational approach under the WHO High Burden High Impact (HBHI) framework adopted in 2019, with stratification incorporated into the NSP and Malaria Operational Plans (MOPs) to guide decision-making and the geographic targeting of interventions. Stratification has progressively integrated malaria burden indicators such as parasite prevalence and under-five mortality, as well as health-system capacity, population density, proximity to water bodies, and access to healthcare, highlighting substantial regional heterogeneity, including parasite prevalence ranging from 8% in Centre to 61% in Sud-Ouest in 2014 (Institut National de la Statistique et de la Démographie, 2014). These maps have supported differentiated interventions, including the phased district-level expansion of seasonal malaria chemoprevention, while more recent planning also recognizes refugee and internally displaced populations as a distinct programmatic stratum (Secrétariat permanent/PNLP, 2023; ALMA Scorecard, 2023).

**Figure:** Burkina-Faso-stratification-2020
**Caption:** Risk strata combining all-cause under-five mortality, parasite prevalence, and malaria incidence
 **Source:** PLAN STRATEGIQUE NATIONAL DE LUTTE CONTRE LE PALUDISME 2021-2025 , Programme National de Lutte contre le Paludisme, 2020

---

## 9. Environment and Seasonality

Malaria transmission follows Burkina Faso's ecological gradient from the arid Sahelian north through a transitional Sudano-Sahelian center to the more humid Sudanian south, with rainfall governing breeding-site availability and temperature governing vector survival (Zongo et al, 2026). Elevated transmission lasts up to three months in the north, roughly six months in the center, and up to nine months in the south, with a median lag of about 10 weeks between rainfall onset and the resulting rise in cases. This longer, more sustained transmission window in the south is consistent with the higher case burden documented there in routine surveillance, while three major river basins: the Volta, Niger, and Comoé further shape vector habitat distribution nationally.

Table 3: Environment and seasonality
| Zone | Annual rainfall | Rainy season | Dominant vector |
|---|---|---|---|
| Sahelian (north) | 300–600 mm | ~June–September (shortest) | *An. coluzzii* (74.9%) |
| Sudano-Sahelian (center) | 600–900 mm | ~4–5 months | *An. coluzzii* (71.2%) |
| Sudanian (south) | 900–1,300 mm | ~June–October (~6 months) | *An. gambiae s.s.* (53.8%) |

---

## 10. Vector Profile

Anopheles gambiae and An. coluzzii are the predominant malaria vectors in Burkina Faso, with composition varying by ecological zone. An. coluzzii dominant in the Sahelian (74.9%) and Sudano-Sahelian (71.2%) zones, and An. gambiae s.s. most frequent in the Sudanian zone (53.8%) while An. arabiensis, a secondary vector, has recently been observed expanding into the West and Southwest, areas where it was previously absent (Zongo et al., 2026). Pyrethroid resistance is widespread, with An. gambiae resistant to all pyrethroids tested nationally, driving adoption of PBO-synergist and G2/Interceptor (chlorfenapyr) nets in place of standard pyrethroid-only nets (ALMA Scorecard, 2023). Entomological inoculation rates (EIR) have not been meaningfully reduced by IRS but remain significantly elevated outdoors even where PBO nets were rolled out from 2019, indicating a substantial outdoor/residual transmission component not fully addressed by current indoor-focused tools.

**Figure (maps recommended):** burkina_faso_vector_zones
**Caption:** Vector distribution 
**Source:** Zongo et al., 2026

**Resistance profile:** 

Table 4: Resistance profile
| Species | Insecticide class | Finding | Year | Source |
|---|---|---|---|---|
| *An. gambiae* | Pyrethroids | Resistance confirmed nationwide, to all pyrethroids tested | Ongoing (monitoring since 2015) | ALMA Scorecard, 2023 |
| *An. gambiae* s.l. | Target-site (*kdr* L1014F) | Widespread, high frequency, stable | — | PLoS ONE, PMC4117487 |
| *An. gambiae* s.l. | Target-site (*kdr* L1014S) | Increasing significantly across much of the country | — | PLoS ONE, PMC4117487 |
| *An. gambiae*, *An. arabiensis* | Organophosphate/carbamate (*ace-1* G119S, G116S) | Present in both species; G116S in *An. arabiensis* newly documented | — | PLoS ONE, PMC4117487 |
| *An. gambiae* s.l. (Kampti/Gaoua, southwest) | PBO-synergized pyrethroids | Synergistic effect already diminishing in high-resistance settings; metabolic genes CYP6M2/CYP6Z1 overexpressed | 2021–2023 | PMC12797545 |
| *An. arabiensis* (Ouagadougou) | Pyrethroids | High resistance associated with high 1014F/1014S *kdr* frequencies; resistance spreading to urban areas | 2024/2025 | Somda et al. |
---

## 11. References

| Title | URL | Description | Tag |
|---|---|---|---|
| World Bank (2025) | data.worldbank.org | Population, key indicators | Epidemiology |
| WHO Global Health Observatory / World Malaria Report (2024) | who.int/teams/global-malaria-programme | Estimated incidence, mortality, population-at-risk | Epidemiology |
| Enquête Démographique et de Santé du Burkina Faso (EDSBF-V), INSD (2021) | — | National prevalence, ITN, IPTp, ACT indicators | Epidemiology |
| Enquête sur les Indicateurs du Paludisme au Burkina Faso (EIPBF), INSD (2014, 2017–18) | — | Regional prevalence, ITN, IPTp, ACT indicators | Epidemiology |
| ALMA Scorecard for Accountability and Action (2022–2023) | alma2030.org | HMIS-sourced case/death counts, resistance/drug-testing status | Epidemiology |
| Institut Géographique du Burkina (IGB), via OCHA HDX (2026) | data.humdata.org/dataset/burkina-faso-administrative-boundaries | Administrative boundary shapefiles (ADM0–ADM3) | Health System |
| GRID3 (2023) | grid3.org | Health district boundary dataset | Health System |
| Secrétariat permanent pour l'élimination du paludisme/PNLP - Réunion Abidjan (2023) | — | Official programmatic report: SNIS case/death data, campaign results | Policy/Strategic Plan |
| Plan Stratégique National de Lutte contre le Paludisme 2016–2020, PNLP | — | National mortality/incidence reduction targets | Policy/Strategic Plan |
| Plan Stratégique National de Lutte contre le Paludisme 2021–2025, PNLP (2020) | — | Risk stratification map, NSP/MOP targeting | Policy/Strategic Plan |
| WHO/PNLP HBHI Technical Consultation (2019) | — | HBHI 4-pillar framework, stratification as planning pillar | Policy/Strategic Plan |
| DHIS2.org (2020) | dhis2.org | DHIS2 integration timeline, 2014–2017 data quality assessment | Health System |
| Ministère de la Santé, Burkina Faso (2017) | — | Stratégie Nationale de Financement de la Santé pour la CSU 2017–2030 | Health System |
| Ministry of Health, Burkina Faso, via Burkina 24 (2016; 2023) | — | ASBC (CHW) recruitment figures | Health System |
| WHO Regional Office for Africa (2018) | afro.who.int | 2017 LLIN mass campaign, routine case/death figures | Intervention |
| WHO Regional Office for Africa (2018) | afro.who.int/node/10108 | Free-care policy (Gratuité) adoption and first-year results | Health System |
| WHO Regional Office for Africa Biennial Report (2024–2025) | afro.who.int | Malaria vaccine expansion to all 70 health districts | Intervention |
| Zongo et al. (2026) — Spatial Distribution and Biodiversity of Anopheles Mosquito Species Across Climatic Zones in Burkina Faso | pmc.ncbi.nlm.nih.gov/articles/PMC12846355 | Zone-specific vector species composition and climate data | Vector Bionomics |
| Distribution and Frequency of *kdr* Mutations within *Anopheles gambiae* s.l. Populations — PLoS ONE | pmc.ncbi.nlm.nih.gov/articles/PMC4117487 | L1014F/L1014S *kdr* and *ace-1* mutation frequencies | Resistance |
| Impact of combined vector control interventions on *An. gambiae* s.l. resistance dynamics, Southwestern Burkina Faso (2021–2023) | pmc.ncbi.nlm.nih.gov/articles/PMC12797545 | PBO-ITN resistance erosion, metabolic resistance genes | Resistance |

---

